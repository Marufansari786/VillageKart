<?php
session_start();
include("includes/db.php");
?>