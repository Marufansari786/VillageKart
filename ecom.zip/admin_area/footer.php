
<!-- Main div -->
</div>   
  </div>
<!-- main div end -->


          <!-- row end -->
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:./partials/_footer.html -->
        <footer class="footer float-right col-md-12 p-0">
          <div class="card ">
            <div class="card-body" style="background-image: linear-gradient(#5c8321, #7fad39);">
              <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class=" d-block text-center text-sm-left d-sm-inline-block text-light">Copyright © Digizest.in 2022-2023</span>
                <span class="text-muted d-block text-center text-sm-left d-sm-inline-block text-light">Distributed By: <a class="text-light" href="https://www.themewagon.com/" target="_blank">digizest</a></span>
                <span class="float-none  float-sm-right d-block mt-1 mt-sm-0 text-center"><a class="text-light" href="https://digizest.in/" target="_blank">Digizest.in</a></span>
              </div>
            </div>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>